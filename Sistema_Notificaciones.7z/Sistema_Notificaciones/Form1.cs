﻿using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Registro = Sistema_Notificaciones.Inicio_sesion;

namespace Sistema_Notificaciones
{
    public partial class Form1 : Form
    {

        public class RegistroSingleton
        {
            private static Registro _instance;
            private static object _lock = new object();

            private RegistroSingleton() { }

            public static Registro GetInstance()
            {
                if (_instance == null)
                {
                    lock (_lock)
                    {
                        if (_instance == null)
                        {
                            _instance = new Registro();
                        }
                    }
                }
                return _instance;
            }
        }
        private static Registro _Registro;
        public Form1()
        {
            InitializeComponent();




        }


        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {
            {
                if (_Registro == null)
                {
                    _Registro = new Registro();
                    _Registro.Show();
                }
                else
                {
                    _Registro.Activate();
                }


            }
        }


    }
   }

