﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net.Mail;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Registro = Sistema_Notificaciones.Inicio_sesion;


namespace Sistema_Notificaciones
{
    public partial class Inicio : Form
    {
        public Inicio()
        {
            InitializeComponent();
        }




        String Destinatario;
        const String Usuario = "Adolfodelosantos23@gmail.com";
        const string Password = "Cargador94";
        string De = "Adolfodelosantos23@gmail.com";
        StringBuilder Mensaje = new StringBuilder ("Cupos de las materias: \n Programacion 1: 14/25 \n Calculo: 23/25 \n Historia: 30/30 ");
        String Asunto = "Disponibilidad de cupos materias";

        string adresses;
        public void EnviarCorreo(StringBuilder Mensaje, DateTime FechaEnvio, string De, string Para, String Asunto, out string Error)
        {


            string Destinatario = txtCorreo.Text.ToString();


            try
            {
                Mensaje.Append(Environment.NewLine);
                Mensaje.Append(string.Format("Este correo ha sido enviado el dia {0:dd/mm/yyyy} a las {0:HH/mmm/ss} hrs \n\n", FechaEnvio));
                Mensaje.Append(Environment.NewLine);
                MailMessage mail = new MailMessage();
                mail.From = new MailAddress(De);    
                mail.To.Add(Para);
                mail.Subject = Asunto;
                mail.Body = Mensaje.ToString();
                SmtpClient smtp = new SmtpClient("smtp.gmail.com");
                smtp.Port = 587;
                smtp.UseDefaultCredentials = false;
                smtp.Credentials = new System.Net.NetworkCredential(Usuario, Password);
                smtp.EnableSsl = true;
                smtp.Send(mail);


                Error = "";

            }
            catch (Exception ex)
            {
                Error = "Error = " + ex.Message;
                MessageBox.Show(Error);


                return;
            }
        }
        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)

        {
            try
            {
                string Error;  
                EnviarCorreo(Mensaje, DateTime.Now, De, txtCorreo.Text, Asunto, out Error);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error sending email: " + ex.Message);
            }
        
        }
    }
}
